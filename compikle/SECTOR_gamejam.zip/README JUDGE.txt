so basically as im shit at coding this is memory leak sim so be careefefual
its fine just dont play for 2 ms

it runs fine so enjoy also use the wasd keys or the arror keys to move i added that in a bad place